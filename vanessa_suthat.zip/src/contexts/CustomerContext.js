import React, { createContext } from "react"

export const CustomerContext = createContext([])
export const UserContext = createContext({})
